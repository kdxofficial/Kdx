<?php
error_reporting(0);
$token = '46837b-7eddc1-f0e282-62a9b7-8b9bcb'; // Your Token, (Url:http://example.com/Settings).
$secret = 'nUQUx3rMBy'; // Your Secret Key, (Url:http://example.com/Settings).
$AHKWEB_ENVIRONMENT = 'PROD'; // PROD, TEST
?>